import sys
studeninfo = dict()

f = open(sys.argv[1], "r", encoding= "utf-8")

for line in f:
    name = line.split(":")[0]
    studeninfo[name] = (line.split(":")[1]).split(",")

for item in sys.argv[2].split(","):
    try:
        university = studeninfo[item][0]
        departmant = studeninfo[item][1]
        print("Name: {}\n University: {}\n Departmant: {}\n".format(str(item), university,departmant))
    except KeyError:
        print("No record of {}".format(item))

